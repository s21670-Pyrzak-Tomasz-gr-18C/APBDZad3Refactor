﻿using System;

namespace XYZExporter
{
    internal class Student
    {
        public Student(string v1, string v2, string v3, string v4, string v5, string v6, string v7, string v8, string v9)
        {
        }

        public string fname { get; set; }
        public string lname { get; set; }
        public string studiesName { get; set; }
        public string studiesMode { get; set; }
        public int indexNumber { get; set; }
        public DateTime birthdate { get; set; }
        public string email { get; set; }
        public string fathersName { get; set; }
        public string mothersName { get; set; }
    }


}